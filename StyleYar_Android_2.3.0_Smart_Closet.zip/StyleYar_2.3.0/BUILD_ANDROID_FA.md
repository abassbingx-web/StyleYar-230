# ساخت APK استایل‌یار

این مخزن سورس Android است. برای ساخت APK:

1. Android Studio را نصب کنید.
2. پوشه `styleyar_real` را Open کنید.
3. Gradle Sync را انجام دهید.
4. از مسیر Build > Build APK(s) نسخه debug را بسازید.
5. برای انتشار، keystore اختصاصی بسازید و نسخه release را امضا کنید.

Backend را جداگانه با Docker اجرا کنید و مقدار API در `index.html` یا تنظیمات اپ را به دامنه HTTPS سرور تغییر دهید.

**کلید OpenAI را هرگز داخل APK قرار ندهید.**


## نسخه 2.3.0
Workflow در مسیر `.github/workflows/android.yml` با نام `StyleYar 2.3.0 Android Build` اجرا می‌شود. پس از موفقیت، artifact با نام `StyleYar-2.3.0-debug-APK` در صفحه اجرای Actions قرار می‌گیرد.
